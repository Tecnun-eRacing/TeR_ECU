*PADS-LIBRARY-PART-TYPES-V9*

BTT62004ESAXUMA1 SOP65P600X115-25N I ANA 7 1 0 0 0
TIMESTAMP 2024.04.25.22.20.16
"Mouser Part Number" 726-BTT62004ESAXUMA1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/BTT62004ESAXUMA1?qs=unwgFEO1A6tpV1sLwJtTRA%3D%3D
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" BTT62004ESAXUMA1
"Description" Quad Channel Smart High-Side Power Switch
"Datasheet Link" https://componentsearchengine.com/Datasheets/2/BTT62004ESAXUMA1.pdf
"Geometry.Height" 1.15mm
GATE 1 25 0
BTT62004ESAXUMA1
1 0 U NC_1
2 0 U IN0
3 0 U NC_2
4 0 U GND
5 0 U IN1
6 0 U DEN
7 0 U IS
8 0 U DSEL0
9 0 U IN2
10 0 U IN3
11 0 U DSEL1
12 0 U NC_3
25 0 U EP
24 0 U OUT0
23 0 U NC_11
22 0 U NC_10
21 0 U NC_9
20 0 U OUT1
19 0 U NC_8
18 0 U NC_7
17 0 U OUT2
16 0 U NC_6
15 0 U NC_5
14 0 U NC_4
13 0 U OUT3

*END*
*REMARK* SamacSys ECAD Model
2886544/1219992/2.50/25/3/Integrated Circuit
